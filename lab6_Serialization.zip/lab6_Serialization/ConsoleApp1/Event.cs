﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
    {
    [Serializable]
    public class Event
        {
       public int EventNumber { get; set; }
        public string Location { get; set; }
        };
    }
