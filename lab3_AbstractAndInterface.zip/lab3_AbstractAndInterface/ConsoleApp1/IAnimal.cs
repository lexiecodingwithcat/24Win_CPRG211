﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
    {
    public interface IAnimal
        {
        //string Name { get; set; }
        //string color { get; set; }
        string Height { get; set; }
        //int age { get; set; }

        string Cry();
      
       


        }
    }
